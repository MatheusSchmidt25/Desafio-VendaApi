package br.unipar.programacaointernet.vendaapi.model;

import java.math.BigDecimal;

public class RelatorioVendas {

    private BigDecimal valorTotal;
    private String nomeCliente;

    public BigDecimal getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(BigDecimal valorTotal) {
        this.valorTotal = valorTotal;
    }

    public String getNomeCliente() {
        return nomeCliente;
    }

    public void setNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }
}
