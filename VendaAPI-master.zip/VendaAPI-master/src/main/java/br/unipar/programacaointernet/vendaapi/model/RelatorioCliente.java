package br.unipar.programacaointernet.vendaapi.model;

public class RelatorioCliente {

    private String cliente;
    private int qtdVendas;

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public int getQtdVendas() {
        return qtdVendas;
    }

    public void setQtdVendas(int qtdVendas) {
        this.qtdVendas = qtdVendas;
    }
}
