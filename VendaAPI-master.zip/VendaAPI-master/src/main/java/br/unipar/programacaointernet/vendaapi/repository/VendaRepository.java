package br.unipar.programacaointernet.vendaapi.repository;

import br.unipar.programacaointernet.vendaapi.model.RelatorioCliente;
import br.unipar.programacaointernet.vendaapi.model.RelatorioVendas;
import br.unipar.programacaointernet.vendaapi.model.Venda;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Stateless
public class VendaRepository {

    @PersistenceContext(unitName = "HibernateMaven")
    private EntityManager em;


    public List<Venda> listar() {
        String jpql = "SELECT p FROM Venda p";
        return em.createQuery(jpql, Venda.class).getResultList();
    }

    public Venda buscarPorID(Integer id) {
        return em.find(Venda.class, id);
    }

    public void cadastrar(Venda venda) throws Exception {
        try {
            em.persist(venda);
        } catch (Exception ex) {
            throw new Exception("Venda não pode ser cadastrado");
        }
    }
    public RelatorioCliente buscarRelatorioClientes(int id) {
        String jpql = "SELECT p FROM Venda p WHERE p.cliente.id = :id";
        List<Venda> vendas = em.createQuery(jpql, Venda.class).setParameter("id", id).getResultList();
        RelatorioCliente rel = new RelatorioCliente();
        rel.setCliente(vendas.get(0).getCliente().getNome());
        rel.setQtdVendas(vendas.size());
        return rel;
    }
    public List<Venda> buscarPorValorTotal(BigDecimal valor) {
        String jpql = "SELECT p FROM Venda p WHERE p.total = :valor";
        return em.createQuery(jpql, Venda.class).setParameter("valor", valor).getResultList();
    }

    public void editar(Venda venda) throws Exception {
        try {
            em.merge(venda);
        } catch (Exception ex) {
            throw new Exception("Venda não pode ser editado");
        }
    }

    public void excluir(Venda venda) throws Exception {
        try {
            em.remove(em.getReference(Venda.class, venda.getId()));
        } catch (Exception ex) {
            throw new Exception("Venda não pode ser excluído.");
        }
    }

    public List<RelatorioVendas> relatorioVendas(){
        List <RelatorioVendas> relatorio = new ArrayList<>();
        String jpql = "SELECT p FROM Venda p";
        List<Venda> vendas = em.createQuery(jpql, Venda.class).getResultList();
        vendas.forEach(venda -> {
            RelatorioVendas rel = new RelatorioVendas();
            rel.setNomeCliente(venda.getCliente().getNome());
            rel.setValorTotal(venda.getTotal());
            relatorio.add(rel);
        });
        return relatorio;
    }
}
